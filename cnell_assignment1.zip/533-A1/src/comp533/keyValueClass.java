package comp533;

public class keyValueClass<K, V> {
	public K KeyType;
	public V Value;
	public keyValueClass(K type, V v) {
		this.KeyType = type;
		this.Value = v;
	}
	public String toString() {
		return "(" + KeyType + "," + Value  + ")";
	}
	public K getKey() {
		return KeyType;
	}
	public V getValue() {
		return Value;
	}
}
