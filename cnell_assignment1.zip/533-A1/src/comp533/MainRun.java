package comp533;

public class MainRun {
	public static void main(String[] args) {
		modelClass model = new modelClass();
		viewClass view = new viewClass();
		controllerClass controller = new controllerClass(model, view);
		controller.start();
	}
}
