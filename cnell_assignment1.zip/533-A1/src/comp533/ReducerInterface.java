package comp533;
import java.util.List;
import java.util.Map;

public interface ReducerInterface<K, V> {
	public Map<K, V> reduce(List<keyValueClass<K, V>> a);
}
