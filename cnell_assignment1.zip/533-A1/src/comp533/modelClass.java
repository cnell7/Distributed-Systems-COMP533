package comp533;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gradingTools.comp533s19.assignment0.AMapReduceTracer;

public class modelClass extends AMapReduceTracer {
	private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
	public String InputString;
	public Map<String, Integer> Result;
	public ArrayList<PropertyChangeListener> Observers;
	public MapperInterface<String, Integer> mapper = mapperFactory.getMapper();
	public intSummingMapperInterface<String, Integer> mapperSum;
	public ReducerInterface<String, Integer> reducer = reducerFactory.getReducer();
	// Getters & Setters
	public String getInputString() {
		return this.InputString;
	}
	public void setInputString(String newString) {
		String oldString = this.InputString;
		this.InputString = newString;
		this.pcs.firePropertyChange(new PropertyChangeEvent(this, "InputString", oldString, newString));
		start();
	}
	public Map<String, Integer> getResult() {
		return this.Result;
	}
	public void setResult(Map<String, Integer> newResult) {
		Map<String, Integer> oldMap = this.Result;
		this.Result = newResult;
		this.pcs.firePropertyChange(new PropertyChangeEvent(this, "Result", oldMap, newResult));
	}
	public void setMapper(intSummingMapperClass smc) {
		mapperSum = smc;
		super.traceMapperChange(intSummingMapperClass.class, smc);
	}
	// Methods
	public void start () {
		if (mapperSum != null) {
			final String[] whiteSpaceInput = InputString.split(" ");
			List<keyValueClass<String, Integer>> map = new ArrayList<keyValueClass<String, Integer>>();
		    for (String s:whiteSpaceInput) {
		    	if (!s.equals(" ")) {
		    		map.add(mapperSum.map(s));
		    	}
		    }
		    Map<String, Integer> hm = reducer.reduce(map);
			setResult(hm);
		} else {
			final String[] whiteSpaceInput = InputString.split(" ");
			List<keyValueClass<String, Integer>> map = new ArrayList<keyValueClass<String, Integer>>();
		    for (String s:whiteSpaceInput) {
		    	if (!s.equals(" ")) {
		    		map.add(mapper.map(s));
		    	}
		    }
		    Map<String, Integer> hm = reducer.reduce(map);
			setResult(hm);
		}
	}
	public void addPropertyChangeListener (PropertyChangeListener aListener) {
		this.pcs.addPropertyChangeListener(aListener);
	}
	public String toString() {
		return "Model";
	}
}
