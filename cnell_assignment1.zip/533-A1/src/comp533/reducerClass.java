package comp533;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gradingTools.comp533s19.assignment0.AMapReduceTracer;

public class reducerClass extends AMapReduceTracer implements ReducerInterface<String, Integer>{

	public Map<String, Integer> reduce(List<keyValueClass<String, Integer>> input) {
		Map<String, Integer> hm = new HashMap<String, Integer>();
        for (keyValueClass<String, Integer> item: input) {
        	if(hm.containsKey(item.getKey())) {
        		hm.put(item.getKey(), hm.get(item.getKey()) + item.getValue());
        	} else {
    			hm.put(item.getKey(), item.getValue());
    		}
        }
        super.traceReduce(input, hm);
		return hm;
	}

}
