package comp533;

import gradingTools.comp533s19.assignment0.AMapReduceTracer;

public class intSummingMapperClass extends AMapReduceTracer implements intSummingMapperInterface<String, Integer>{
	final String sum = "Sum";
	public keyValueClass<String, Integer> map(String stringArg) {
		keyValueClass<String, Integer> temp = new keyValueClass<String, Integer>(sum, Integer.parseInt(stringArg));
		super.traceMap(sum, temp.getValue());
		return temp;
	}
}
