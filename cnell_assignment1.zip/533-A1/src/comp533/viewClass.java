package comp533;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Map;

import gradingTools.comp533s19.assignment0.AMapReduceTracer;

public class viewClass extends AMapReduceTracer implements PropertyChangeListener {
	public void propertyChange(PropertyChangeEvent evt) {
		super.tracePropertyChange(evt);
	}
	public String toString() {
		return "View";
	}
}
