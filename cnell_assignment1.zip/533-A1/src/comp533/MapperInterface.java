package comp533;

public interface MapperInterface<K, V> {
	public keyValueClass<K, V> map (K k);
}
