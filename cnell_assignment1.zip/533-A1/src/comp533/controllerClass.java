package comp533;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import gradingTools.comp533s19.assignment0.AMapReduceTracer;

public class controllerClass extends AMapReduceTracer {
	modelClass modal;
	public controllerClass(modelClass m, viewClass v) {
		this.modal = m;
		modal.addPropertyChangeListener(v);
	}
	public void start() {
		final Scanner Scanner = new Scanner(System.in);
		while (true) {
			super.traceNumbersPrompt();
			String input = Scanner.nextLine();
			if (input.equals("quit")) break;
			modal.setInputString(input);
		}
		super.traceQuit();
	}
	public String toString() {
		return "Controller";
	}
}
