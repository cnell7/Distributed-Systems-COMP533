package comp533;

public class reducerFactory {
	public static ReducerInterface<String, Integer> Reducer = new reducerClass();
	public static ReducerInterface<String, Integer> getReducer() {
		return Reducer;
	}
	public static void setReducer(ReducerInterface<String, Integer> r){
		Reducer = r;
	}
}
