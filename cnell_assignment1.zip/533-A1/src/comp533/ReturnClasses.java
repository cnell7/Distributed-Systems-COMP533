package comp533;
import gradingTools.comp533s20.assignment1.mappers.IntSummingMapper;
import gradingTools.comp533s21.assignment1.interfaces.MapReduceConfiguration;
public class ReturnClasses implements MapReduceConfiguration {

	@Override
	public Object getBarrier(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getBarrierClass() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getClientTokenCounter() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getControllerClass() {
		return controllerClass.class;
	}

	@Override
	public Object getIntSummingMapper() {
		return new intSummingMapperClass();
	}

	@Override
	public Class getIntSummingMapperClass() {
		return intSummingMapperClass.class;
	}

	@Override
	public Object getJoiner(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getJoinerClass() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getKeyValueClass() {
		return keyValueClass.class;
	}

	@Override
	public Class getMapperFactory() {
		return mapperFactory.class;
	}

	@Override
	public Class getModelClass() {
		return modelClass.class;
	}

	@Override
	public Object getPartitioner() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getPartitionerClass() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getPartitionerFactory() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getReducer() {
		return new reducerClass();
	}

	@Override
	public Class getReducerClass() {
		return reducerClass.class;
	}

	@Override
	public Class getReducerFactory() {
		return reducerFactory.class;
	}

	@Override
	public Class getRemoteClientObjectClass() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getRemoteClientObjectInterface() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getRemoteModelInterface() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getServerIntegerSummer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getServerTokenCounter() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getSlaveClass() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class getStandAloneIntegerSummer() {
		return standAloneIntegerSummer.class;
	}

	@Override
	public Class getStandAloneTokenCounter() {
		return MainRun.class;
	}

	@Override
	public Object getTokenCountingMapper() {
		return new tokenCountingMapperClass();
	}

	@Override
	public Class getTokenCountingMapperClass() {
		return tokenCountingMapperClass.class;
	}

	@Override
	public Class getViewClass() {
		return viewClass.class;
	}
	
}
