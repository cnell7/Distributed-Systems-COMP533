package comp533;

import gradingTools.comp533s19.assignment0.AMapReduceTracer;

public class tokenCountingMapperClass extends AMapReduceTracer implements MapperInterface<String, Integer> {
	public keyValueClass<String, Integer> map(String s) {
		keyValueClass<String, Integer> temp = new keyValueClass<String, Integer>(s, 1);
		super.traceMap(s, temp.getValue());
		return temp;
	}
}
