package comp533;

public class mapperFactory {
	public static MapperInterface<String, Integer> Mapper = new tokenCountingMapperClass();
	public static MapperInterface<String, Integer> getMapper() {
		return Mapper;
	}
	public static void setMapper(MapperInterface<String, Integer> m){
		Mapper = m;
	}
}
