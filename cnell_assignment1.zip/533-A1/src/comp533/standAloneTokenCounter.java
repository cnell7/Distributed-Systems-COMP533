package comp533;
import java.util.Scanner;
import java.util.*; 

public class standAloneTokenCounter {
	public static void main(String[] args) {
		System.out.println(processInput());
	}
	public static String processInput() {
	    String output = "";
	    final Map<String, Integer> hm = new HashMap<String, Integer>(); 
		final Scanner Scanner = new Scanner(System.in);  
	    System.out.println("Please enter quit or a line of tokens to be processed separated by spaces");
	    final String input = Scanner.nextLine();
	    final String[] whiteSpaceInput = input.split(" ");
	    Scanner.close();
	    for (String s:whiteSpaceInput) {
	    	if (!s.equals(" ")) {
	    		if (hm.containsKey((s))) {
	    			hm.put(s, hm.get(s) + 1);
	    		} else {
	    			hm.put(s, 1);
	    		}
	    	}
	    }
	    for (Map.Entry mapElement : hm.entrySet()) { 
            String key = (String)mapElement.getKey(); 
            int value = ((int)mapElement.getValue()); 
            output += key + "=" + value + ", ";
        }
	    output = output.substring(0, output.length() - 2);
	    return output;
	}
	public static Class<standAloneTokenCounter> getTokenCounter() {
		return standAloneTokenCounter.class;
	}
}
