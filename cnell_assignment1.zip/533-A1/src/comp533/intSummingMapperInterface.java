package comp533;

public interface intSummingMapperInterface<K, C> {
	public keyValueClass<String, Integer> map(String stringArg);
}
