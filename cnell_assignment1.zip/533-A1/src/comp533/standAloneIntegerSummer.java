package comp533;

public class standAloneIntegerSummer {
	public static void main(String args[]) {
		modelClass model = new modelClass();
		viewClass view = new viewClass();
		model.setMapper(new intSummingMapperClass());
		controllerClass controller = new controllerClass(model, view);
		controller.start();
	}
}
