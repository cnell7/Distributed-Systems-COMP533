package a0;

public class Hello {
	public static void main(final String[] args) {
		System.out.println("Hello World");
		System.out.println("Goodbye World");
	}

}